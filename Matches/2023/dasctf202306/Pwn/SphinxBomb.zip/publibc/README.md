 # SphinxBomb

一个简单的问题，你只询问 Sphinx 即可。
